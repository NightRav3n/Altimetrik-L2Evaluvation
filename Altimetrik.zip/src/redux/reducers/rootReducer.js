import { combineReducers } from "redux";
import article from "./article";
import { connectRouter } from "connected-react-router";
import { createBrowserHistory } from "history";
export default combineReducers({
  article,
  router: connectRouter(createBrowserHistory())
});
