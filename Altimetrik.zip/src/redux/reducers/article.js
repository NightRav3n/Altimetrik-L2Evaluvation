import {
  FORM_VALIDATOR,
  REGISTRATION_HANDLER,
  LOGIN_HANDLER
} from "../constants";

const initialState = {
  user: {
    userName: "",
    password: "",
    firstName: "",
    lastName: "",
    email: "",
    gender: "",
    country: ""
  }
};

export default (state = initialState, action) => {
  switch (action.type) {
    case FORM_VALIDATOR:
      const { id, value } = action.payload.target;
      state.user[id] = value;
      return state;

    case REGISTRATION_HANDLER:
      localStorage.setItem("userDetails", JSON.stringify(state.user));
      alert("User Registered Successfully");
      return state;

    case LOGIN_HANDLER:
      if (
        (state.user.userName === "Master" || state.user.userName === "User") &&
        (state.user.password === "Default" || state.user.password === "Access")
      ) {
        alert("Please wait till you have been redirected to HomePage");
        window.location.href = "/Home";
      } else alert("Invalid Credentials...");
      return state;

    default:
      return state;
  }
};
