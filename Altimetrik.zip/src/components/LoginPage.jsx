import React from "react";

import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import { Link } from "react-router-dom";

import {
  Container,
  Button,
  Form,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Input,
  Card,
  CardBody,
  Row,
  Col,
  CardTitle
} from "reactstrap";

import { inputEntered, loginFormBtnClicked } from "../redux/actions";

class LoginPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <Container>
        <Card>
          <CardTitle className="p-1 card-title">Login Form</CardTitle>
          <CardBody>
            <Form>
              <InputGroup>
                <InputGroupAddon addonType="prepend">
                  <InputGroupText>User Name</InputGroupText>
                </InputGroupAddon>
                <Input
                  placeholder="Please Enter Your UserName"
                  type="text"
                  name="userName"
                  id="userName"
                  onChange={this.props.inputEntered}
                />
              </InputGroup>
              <br />
              <InputGroup>
                <InputGroupAddon addonType="prepend">
                  <InputGroupText>Password..</InputGroupText>
                </InputGroupAddon>
                <Input
                  placeholder="Please Enter Your Password"
                  type="password"
                  name="password"
                  id="password"
                  onChange={this.props.inputEntered}
                />
              </InputGroup>

              <Row className="mx-6 p-4">
                <Col />
                <Col md="8">
                  <Button
                    color="primary"
                    onClick={this.props.loginFormBtnClicked}
                  >
                    Sign In
                  </Button>
                </Col>
                <Col />
              </Row>
              <span className="p-3">
                <Link to="/signup">Don't have an account? Register Here</Link>
              </span>
            </Form>
          </CardBody>
        </Card>
      </Container>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({ inputEntered, loginFormBtnClicked }, dispatch);
}

export default connect(
  null,
  mapDispatchToProps
)(LoginPage);
