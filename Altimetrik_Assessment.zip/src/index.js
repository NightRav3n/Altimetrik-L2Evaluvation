import React from "react";
import ReactDOM from "react-dom";

import "bootstrap/dist/css/bootstrap.min.css";

import App from "./App";
import Header from "../src/components/common/Header.jsx";
import Footer from "../src/components/common/Footer.jsx";

import { Provider } from "react-redux";
import { ConnectedRouter } from "connected-react-router";

import store, { history } from "../src/redux/store/configureStore";

const rootElement = document.getElementById("root");
ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <ConnectedRouter history={history}>
        <App />
      </ConnectedRouter>
    </Provider>
  </React.StrictMode>,
  rootElement
);
