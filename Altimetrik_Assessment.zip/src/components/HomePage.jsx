import React from "react";
import { Link } from "react-router-dom";
import { Button } from "reactstrap";

function HomePage() {
  return (
    <div>
      <h5> Welcome to User DashBoard </h5>
      <h6> Page Under Construction</h6>
      <Link to="/">
        <Button className="cancel" color="danger">
          Log Out
        </Button>
      </Link>
    </div>
  );
}

export default HomePage;
