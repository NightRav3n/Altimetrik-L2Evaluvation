import React from "react";

class Footer extends React.Component {
  render() {
    return (
      <footer class="page-footer font-small blue">
        <div class="footer-copyright text-center py-3">
          <a href="https://mdbootstrap.com/">
            {" "}
            Altimetrik - UserName: Master || Password: Default
          </a>
        </div>
      </footer>
    );
  }
}

export default Footer;
