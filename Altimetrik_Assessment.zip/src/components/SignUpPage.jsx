import React from "react";

import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import { Link } from "react-router-dom";

import {
  Container,
  Button,
  Form,
  FormGroup,
  Label,
  Input,
  Card,
  CardBody,
  CardTitle
} from "reactstrap";

import { inputEntered, RegisterFormBtnClicked } from "../redux/actions";

class SignUpPage extends React.Component {
  constructor() {
    super();
    this.state = {};
  }
  render() {
    return (
      <Container fluid>
        <Card>
          <CardTitle className="p-1 card-title">Registration Form</CardTitle>
          <CardBody className="reg-card">
            <Form onSubmit={this.props.RegisterFormBtnClicked}>
              <FormGroup>
                <Label for="userName">User Name</Label>
                <Input
                  placeholder="Please Enter Your UserName"
                  type="text"
                  name="userName"
                  id="userName"
                  onChange={this.props.inputEntered}
                />
              </FormGroup>

              <FormGroup>
                <Label for="password">Password</Label>
                <Input
                  placeholder="Please Enter Your Password"
                  type="password"
                  name="password"
                  id="password"
                  onChange={this.props.inputEntered}
                />
              </FormGroup>

              <FormGroup>
                <Label for="email">Email</Label>
                <Input
                  placeholder="Please Enter Your Email"
                  type="email"
                  name="email"
                  id="email"
                  onChange={this.props.inputEntered}
                />
              </FormGroup>

              <FormGroup>
                <Label for="FirstName">First Name</Label>
                <Input
                  placeholder="Please Enter Your First Name"
                  type="text"
                  name="firstName"
                  id="firstName"
                  onChange={this.props.inputEntered}
                />
              </FormGroup>

              <FormGroup>
                <Label for="LastName">Last Name</Label>
                <Input
                  placeholder="Please Enter Your Last Name"
                  type="text"
                  name="lastName"
                  id="lastName"
                  onChange={this.props.inputEntered}
                />
              </FormGroup>

              <FormGroup>
                <Label for="country">Country</Label>
                <Input
                  type="select"
                  id="country"
                  onChange={this.props.inputEntered}
                >
                  <option>Please Select Your Country</option>
                  <option value="Afganistan">Afghanistan</option>

                  <option value="Bermuda">Bermuda</option>
                  <option value="Canada">Canada</option>
                  <option value="Denmark">Denmark</option>
                  <option value="Egypt">Egypt</option>
                  <option value="El Salvador">El Salvador</option>
                  <option value="Equatorial Guinea">Equatorial Guinea</option>
                  <option value="Finland">Finland</option>
                  <option value="Germany">Germany</option>
                  <option value="Hawaii">Hawaii</option>
                  <option value="India">India</option>
                  <option value="Jamaica">Jamaica</option>
                  <option value="Kenya">Kenya</option>
                  <option value="Latvia">Latvia</option>
                  <option value="Macedonia">Macedonia</option>
                </Input>
              </FormGroup>

              <FormGroup tag="fieldset">
                <Label for="gender">Gender</Label>
                <FormGroup check>
                  <Label check>
                    <Input
                      type="radio"
                      name="gender"
                      id="gender"
                      onChange={this.props.inputEntered}
                    />
                    Male{" "}
                  </Label>
                </FormGroup>
                <FormGroup check>
                  <Label check>
                    <Input
                      type="radio"
                      name="gender"
                      id="gender"
                      onChange={this.props.inputEntered}
                    />
                    Female
                  </Label>
                </FormGroup>
              </FormGroup>

              <Button color="primary">Submit</Button>
              <Link to="/">
                {" "}
                <Button className="cancel" color="danger">
                  Cancel
                </Button>
              </Link>
            </Form>
          </CardBody>
        </Card>
        <span className="p-3">
          <Link to="/">Already Our Valuable User? Click Here to Login</Link>
        </span>
      </Container>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators({ inputEntered, RegisterFormBtnClicked }, dispatch);
};

export default connect(
  null,
  mapDispatchToProps
)(SignUpPage);
