import {
  FORM_VALIDATOR,
  REGISTRATION_HANDLER,
  LOGIN_HANDLER
} from "../constants";

export const inputEntered = validator => {
  return dispatch => {
    dispatch({
      type: FORM_VALIDATOR,
      payload: validator
    });
  };
};

export const RegisterFormBtnClicked = () => {
  return dispatch => {
    dispatch({
      type: REGISTRATION_HANDLER
    });
  };
};

export const loginFormBtnClicked = credentials => {
  return dispatch => {
    dispatch({
      type: LOGIN_HANDLER,
      payload: credentials
    });
  };
};
