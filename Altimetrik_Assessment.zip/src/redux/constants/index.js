export const FORM_VALIDATOR = "article/FORM_VALIDATOR";
export const REGISTRATION_HANDLER = "article/REGISTRATION_HANDLER";
export const LOGIN_HANDLER = "article/LOGIN_HANDLER";
