import React from "react";
import { connect } from "react-redux";
import { Switch, Route } from "react-router-dom";
import "./styles.css";

import HomePage from "../src/components/HomePage.jsx";
import LoginPage from "../src/components/LoginPage.jsx";
import SignUpPage from "../src/components/SignUpPage.jsx";

import Header from "../src/components/common/Header.jsx";
import Footer from "../src/components/common/Footer.jsx";

function App() {
  return (
    <div className="App">
      <Header />
      <Switch>
        <Route exact path="/">
          <LoginPage />
        </Route>
        <Route path="/signUp">
          <SignUpPage />
        </Route>
        <Route path="/Home">
          <HomePage />
        </Route>
      </Switch>
      <Footer />
    </div>
  );
}

export default connect()(App);
